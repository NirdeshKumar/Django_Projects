from django.urls import path
from . import views


urlpatterns = [
    
    path("home",views.home,name='home'),

    path("register",views.register,name="register"),
    path("signup",views.signup,name="signup"),
    path("login",views.login,name="login"),

    path("logout",views.logoutUser,name="logout"),
    path("dashboard",views.dashboard,name="dashboard"),

    path("delete<int:key>",views.delete,name="delete"),
    path("edit/<int:key>",views.edit,name="edit"),
    path("edit/update",views.update,name="update"),  

    path("graph",views.graph,name="graph"),  
    

]