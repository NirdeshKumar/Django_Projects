from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.core.paginator import Paginator,EmptyPage
from django.contrib.auth.hashers import make_password
from django.contrib.auth import authenticate, logout as auth_logout, login as auth_login
from django.contrib.auth.decorators import login_required 
import re
from django.core.mail import send_mail
from django.db import IntegrityError
from django.conf import settings
from collections import OrderedDict

from .forms import EmployeeForm
from .models import EmployeeModel
from django.views.generic import TemplateView

# Create your views here.

@login_required(login_url = 'login')
def home(request):
    return render(request,"home_page.html")


''' To Validation '''
    
def validate_Fname(name):
    pattern = r'^[a-zA-Z]+$'
    return re.match(pattern,name)

def validate_Lname(name):
    pattern = r'^[a-zA-Z]+$'
    return re.match(pattern,name)

def validate_Uname(name):
    pattern = r'^[a-z0-9A-Z]+$'
    return re.match(pattern,name)

''' To Register Page '''
@login_required(login_url = 'login')
def register(request):
    value = EmployeeForm()

    if request.method == "POST":

        name = request.POST['name']
        add = request.POST['add']
        num = request.POST['num']
        email = request.POST['email']
        Designation = request.POST['Designation']
        print("request.user", request.user)
        created_by = request.user

        my_model = EmployeeModel(name=name, add=add, num=num, email=email, Designation=Designation, created_by=created_by)
        my_model.save()

        return redirect(dashboard)

    return render(request, "register.html", {'form': value})

    


''' To Signup Page '''

def signup(request):
    # if request.user.is_authenticated:
    #     return redirect('home')
    # else:
    try:
        if request.method == "POST":
            fname = request.POST.get("FirstName")
            lname = request.POST.get("LastName")
            email = request.POST.get("email")
            user = request.POST.get("user")
            passw = request.POST.get("password") 

            subject = "Your account verification email "
            message = f" Your Registration done Successfully  "
            
            
            if not validate_Fname(fname):
                error_message = 'Invalid First Name'
                return render(request,"signup_page.html",{'error_message':error_message})
            
            if not validate_Lname(lname):
                error_message = 'Invalid Last Name'
                return render(request,"signup_page.html",{'error_message':error_message})
            
            if not validate_Uname(user):
                error_message = 'Invalid User Name'
                return render(request,"signup_page.html",{'error_message':error_message})
            
            
            send_mail(
                    subject,
                    message,
                    settings.EMAIL_HOST_USER, 
                    [email],
                )            
            data = User.objects.create(first_name=fname, last_name=lname, email=email, username=user,password=make_password(passw))
            data.save()     
            # return redirect(login)
            return render(request,"signup_page.html",{"data": "email send","data1": "Registration Successful"})   
        
        return render(request,"signup_page.html")
    except IntegrityError:
        return render(request,'signup_page.html',{"error_message":"User Already Exist!!!"})


''' To Login Page '''
def login(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        if request.method == 'POST':
            user = request.POST.get('user')
            cpass = request.POST.get('pass')
            
            users = authenticate(request, username=user, password=cpass)
            

            if users is not None:
                auth_login(request, users)
                return redirect('dashboard')
            else:
                error_message = 'Invalid User Name or Password'    
                return render(request,"login.html",{"error_message": error_message})      
        return render(request,'login.html')
       
            


''' To Display Dashboard '''

@login_required(login_url = 'login')
def dashboard(request):   

    #data = User.objects.all()
    data = EmployeeModel.objects.filter(created_by=request.user)
    page_num=Paginator(data,2)
    page_nu=request.GET.get("page",1)

    try:
        page=page_num.page(page_nu)
    except EmptyPage:
        page=page_num.page(1)
    
    if request.method=="GET":
        st=request.GET.get("searchname")

        if st is not None:
            data=EmployeeModel.objects.filter(name__icontains=st)
            page=EmployeeModel.objects.filter(name__icontains=st)

    return render(request,'dashboard.html',{'data':page})    
    

''' To Delete the data from the Dashboard '''
def delete(request,key):

    data=EmployeeModel.objects.filter(id=key)
    data.delete()
    return redirect(dashboard)

''' To Edit the data at the dashboard '''
def edit(request,key):
    value = EmployeeForm()
    data=EmployeeModel.objects.filter(id=key)
    return render(request,"update.html",{"data":data,'value': value})


def update(request):

    if request.method == "POST":
        id = request.POST['id']
        name = request.POST['name']
        add = request.POST['add']
        num = request.POST['num']
        email = request.POST['email']
        Designation = request.POST['Designation']
        EmployeeModel.objects.filter(id=id).update(name=name, add=add, num=num, email=email, Designation=Designation)
        
        return redirect(dashboard)   
    
    return render(request, "update.html")


''' To logout '''
def logoutUser(request):
    auth_logout(request)
    return redirect(login)

def graph(request):
    data_tr = EmployeeModel.objects.filter(Designation="Trainee").count()
    total_trainee = int(data_tr)

    data_te = EmployeeModel.objects.filter(Designation="Team_Mamber").count()
    total_Team_Mamber = int(data_te)

    data_srte = EmployeeModel.objects.filter(Designation="Sr_Team_Member").count()
    total_Sr_Team_Member = int(data_srte)

    data_tl = EmployeeModel.objects.filter(Designation="Team_Leader").count()
    total_Team_Leader = int(data_tl)

    Designation_list = ['Trainee','Team_Mamber','Sr_Team_Member','Team_Leader'] 
    number_list = [total_trainee, total_Team_Mamber, total_Sr_Team_Member, total_Team_Leader]

    print(Designation_list,number_list)

    
    return render(request,"home_page.html",{"Designation":Designation_list, "toatl_count":number_list})
    #return HttpResponse(total_Team_Mamber)

