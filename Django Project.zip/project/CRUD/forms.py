from django import forms
from django.core.validators import RegexValidator


class EmployeeForm(forms.Form):

    Post= [
    # Backend Name, Frontend Name
    ('Trainee', 'Trainee'),
    ('Team_Mamber', 'Team Mamber'),
    ('Sr_Team_Member', 'Sr.Team Member'),
    ('Team_Leader', 'Team Leader'),
    ]

    name = forms.CharField()
    add = forms.CharField()
    num = forms.IntegerField()
    email = forms.EmailField()
    Designation = forms.CharField( widget=forms.RadioSelect(choices=Post))

    # Name = forms.CharField( 
    #     label='Name', 
    #     validators=[RegexValidator(r'^[a-zA-ZA-z\s]*$', message="only letter is allowed !")],
    #     widget=forms.TextInput(attrs={'placeholder':'Enter Your Name'}))
    
    # Add = forms.CharField(
    #     label='Address',  
    #     widget=forms.TextInput(attrs={'placeholder':'Enter Your Address '})
    # )

    # num = forms.IntegerField(
    #     label='Mobile', 
    #     validators=[RegexValidator(r"^[0-9]+$", message="only Integer value is allowed !")], 
    #     widget=forms.TextInput(attrs={'placeholder':'9172*******'})
    # )

    # email = forms.EmailField(
    #     label='Email', 
    #     validators=[RegexValidator(r"^[A-Za-z0-9_!#$%&'*+\/=?`{|}~^.-]+@[A-Za-z0-9.-]+$", message="only gmail format is allowed !")], 
    #     widget=forms.TextInput(attrs={'placeholder':'example123@gmail.com'})
    # )


